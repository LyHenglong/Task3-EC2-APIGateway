const express = require('express');
const crypto  = require('crypto');
require('dotenv').config();

const connectDB = require('./dbconnect');
const User      = require('./userSchema');

const app  = express();
// Changed fallback port to 5001 to align with the API Gateway routing map
const PORT = process.env.PORT || 5001; 

// ─── Middleware ──────────────────────────────────────────────────────────────
app.use(express.json());

// ─── Connect to MongoDB ──────────────────────────────────────────────────────
connectDB();

// ─── Helper: hash password with SHA-256 + salt ───────────────────────────────
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto
    .createHmac('sha256', process.env.JWT_SECRET || 'default_secret')
    .update(salt + password)
    .digest('hex');
  return `${salt}:${hash}`;
}

// ─── Routes ──────────────────────────────────────────────────────────────────

// @route   GET /
// @desc    Health check (Helps verify the gateway can reach this microservice)
app.get('/', (req, res) => {
  res.json({ message: 'Registration Microservice is running securely on Port 5001 🚀' });
});

// @route   POST /register
// @desc    Register a new user (Prefix changed from /api/register to match Gateway)
app.post('/register/register', async (req, res) => {
  try {
    const { fullName, email, password, role } = req.body;

    // Validate required fields (Enforced role checking for your assignment assignment)
    if (!fullName || !email || !password || !role) {
      return res.status(400).json({
        success: false,
        message: 'fullName, email, password, and role (student/teacher) are required.',
      });
    }

    // Validate that the role is either student or teacher
    if (role !== 'student' && role !== 'teacher') {
      return res.status(400).json({
        success: false,
        message: 'Invalid role. Role must be either "student" or "teacher".',
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: 'Email is already registered.',
      });
    }

    // Hash the password securely using your salt factory setup
    const hashedPassword = hashPassword(password);

    // Create user with explicit role mapping
    const newUser = new User({
      fullName,
      email,
      password: hashedPassword,
      role: role,
    });

    await newUser.save();

    res.status(201).json({
      success: true,
      message: 'User registered successfully!',
      data: {
        id:       newUser._id,
        fullName: newUser.fullName,
        email:    newUser.email,
        role:     newUser.role,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// @route   GET /users
// @desc    Get all registered users (Cleaned route for easier internal debugging)
app.get('/users', async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json({ success: true, count: users.length, data: users });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// ─── Start Server ────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`=====> Registration Microservice active on http://localhost:${PORT} <=====`);
});